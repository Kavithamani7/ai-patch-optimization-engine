# Quick Start Guide

Get the AI Patch Optimizer running in 5 minutes!

## Prerequisites Check

```bash
# Python version (need 3.9+)
python --version

# Node.js version (need 18+)
node --version

# pip installed
pip --version

# npm installed
npm --version
```

## Installation

### 1. Backend Setup (2 minutes)

```bash
# Navigate to backend directory
cd backend

# Create and activate virtual environment
python -m venv venv

# On macOS/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate

# Install Python dependencies
pip install -r requirements.txt

# This installs:
# - FastAPI (web framework)
# - scikit-learn (ML models)
# - SHAP (explainability)
# - pandas, numpy (data processing)
# - reportlab (PDF generation)
```

### 2. Frontend Setup (2 minutes)

```bash
# Open new terminal, navigate to frontend directory
cd frontend

# Install Node dependencies
npm install

# This installs:
# - React + TypeScript
# - Tailwind CSS
# - Vite (build tool)
```

## Running the Application

### Terminal 1: Start Backend

```bash
cd backend
source venv/bin/activate  # or venv\Scripts\activate on Windows
uvicorn app.main:app --reload
```

**Expected output:**
```
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
```

### Terminal 2: Start Frontend

```bash
cd frontend
npm run dev
```

**Expected output:**
```
VITE v5.0.8  ready in 500 ms

➜  Local:   http://localhost:5173/
➜  Network: use --host to expose
```

### 3. Access the Application

Open your browser to: **http://localhost:5173**

## First Run Walkthrough

### Step 1: Generate Data
1. Click the blue "1. Generate Data" button
2. Wait ~2 seconds
3. You'll see a success notification: "Generated 1000 vulnerabilities..."

### Step 2: Train Models
1. Click "2. Train Models"
2. Wait ~5 seconds while both models train
3. See which model performs better (usually Random Forest)

### Step 3: Optimize
1. Enter "40" in the "Available Patch Hours" field
2. Select your preferred model (or keep Random Forest)
3. Click green "3. Optimize Patches" button
4. See optimized results in ~1 second

### Step 4: Explore Results

**Metrics Cards** show:
- Total vulnerabilities and selected count
- Risk reduced percentage
- Hours used vs available
- Model confidence

**Vulnerability Table** allows you to:
- Sort by any column (click headers)
- Filter by severity
- Search by ID
- Click "Explain" to see SHAP analysis
- Click "What-If" to simulate scenarios

**Business Impact Card** shows:
- Executive summary
- ROI estimate
- Capacity utilization

**Risk Heatmap** visualizes:
- Risk distribution by CVSS × Asset Criticality

### Step 5: Export
- Click "Export to CSV" for spreadsheet analysis
- Click "Export to PDF" for professional report

## Common Issues

### "Backend not running" error
**Problem**: Frontend can't connect to backend  
**Solution**: Make sure backend is running on port 8000

```bash
# Check if backend is running
curl http://localhost:8000
# Should return: {"message": "AI Patch Optimization API v2.0 is running", ...}
```

### Port 8000 already in use
**Solution**: Find and kill the process
```bash
# On macOS/Linux:
lsof -ti:8000 | xargs kill -9

# On Windows:
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

### Port 5173 already in use
**Solution**: Vite will automatically try 5174, 5175, etc.  
Or specify a different port:
```bash
npm run dev -- --port 3000
```

### Module not found errors (Python)
**Solution**: Reinstall dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt --force-reinstall
```

### Module not found errors (Node)
**Solution**: Clear cache and reinstall
```bash
rm -rf node_modules package-lock.json
npm install
```

## Development Mode Features

- **Hot Reload**: Both frontend and backend auto-reload on file changes
- **API Docs**: Visit http://localhost:8000/docs for interactive API documentation
- **Console Logging**: Check browser console for frontend logs, terminal for backend logs

## Production Deployment

For production use, you'll need to:

1. **Build Frontend**:
```bash
cd frontend
npm run build
# Creates optimized build in dist/
```

2. **Serve Frontend**: Use nginx, Apache, or serve static files via FastAPI

3. **Run Backend**: Use production ASGI server
```bash
gunicorn app.main:app --workers 4 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

4. **Environment Variables**: Configure API URL, database, etc.

5. **Security**: Add authentication, HTTPS, rate limiting

## Next Steps

- Read the full [README.md](README.md) for detailed architecture
- Explore the code in `frontend/src/components/`
- Customize the ML models in `backend/app/model.py`
- Add your own data sources in `backend/app/data.py`

## Getting Help

If you encounter issues:
1. Check browser console (F12)
2. Check backend terminal for errors
3. Verify all dependencies installed correctly
4. Ensure ports 8000 and 5173 are available

Enjoy optimizing your patches with AI!
