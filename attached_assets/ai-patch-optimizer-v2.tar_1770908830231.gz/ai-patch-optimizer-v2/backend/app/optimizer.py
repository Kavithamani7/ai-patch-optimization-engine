"""
Enhanced Knapsack Optimization Module
-------------------------------------
Optimizes patch selection using dynamic programming with confidence scores.
"""

import pandas as pd
import numpy as np
from typing import Tuple, List


def knapsack_optimize(
    df: pd.DataFrame,
    predicted_risks: np.ndarray,
    available_hours: float,
    confidence_scores: np.ndarray
) -> dict:
    """
    Solve 0/1 knapsack problem to maximize risk reduction.
    
    Args:
        df: Vulnerability data
        predicted_risks: Predicted risk scores
        available_hours: Maximum patch hours available
        confidence_scores: Prediction confidence (0-1)
        
    Returns:
        Dictionary with optimization results
    """
    n = len(df)
    weights = df['patch_effort_hours'].values
    values = predicted_risks * confidence_scores  # Weight by confidence
    
    # Dynamic programming table
    capacity_int = int(available_hours * 10)  # Use 0.1 hour precision
    weights_int = (weights * 10).astype(int)
    
    # DP table
    dp = np.zeros((n + 1, capacity_int + 1), dtype=float)
    
    # Fill DP table
    for i in range(1, n + 1):
        for w in range(capacity_int + 1):
            if weights_int[i-1] <= w:
                dp[i][w] = max(
                    dp[i-1][w],
                    dp[i-1][w - weights_int[i-1]] + values[i-1]
                )
            else:
                dp[i][w] = dp[i-1][w]
    
    # Backtrack to find selected items
    selected_indices = []
    w = capacity_int
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            selected_indices.append(i-1)
            w -= weights_int[i-1]
    
    selected_indices.reverse()
    
    # Prepare results
    selected_vulns = df.iloc[selected_indices].copy()
    selected_vulns['predicted_risk'] = predicted_risks[selected_indices]
    selected_vulns['confidence'] = confidence_scores[selected_indices]
    selected_vulns['weighted_risk'] = values[selected_indices]
    
    # Calculate metrics
    total_risk = float(predicted_risks.sum())
    risk_reduced = float(predicted_risks[selected_indices].sum())
    hours_used = float(weights[selected_indices].sum())
    
    # Sort by risk (descending)
    selected_vulns = selected_vulns.sort_values('predicted_risk', ascending=False)
    
    # Calculate severity breakdown
    severity_breakdown = calculate_severity_breakdown(selected_vulns)
    
    return {
        'total_vulnerabilities': n,
        'selected_count': len(selected_indices),
        'total_risk': total_risk,
        'risk_reduced': risk_reduced,
        'percentage_reduced': (risk_reduced / total_risk * 100) if total_risk > 0 else 0,
        'hours_used': hours_used,
        'hours_available': available_hours,
        'hours_remaining': available_hours - hours_used,
        'average_confidence': float(confidence_scores[selected_indices].mean()),
        'severity_breakdown': severity_breakdown,
        'selected_vulnerabilities': selected_vulns.to_dict('records')
    }


def calculate_severity_breakdown(df: pd.DataFrame) -> dict:
    """Calculate breakdown by severity levels"""
    def get_severity(cvss):
        if cvss >= 9.0:
            return 'Critical'
        elif cvss >= 7.0:
            return 'High'
        elif cvss >= 4.0:
            return 'Medium'
        else:
            return 'Low'
    
    df['severity'] = df['cvss_score'].apply(get_severity)
    breakdown = df.groupby('severity').agg({
        'vulnerability_id': 'count',
        'predicted_risk': 'sum',
        'patch_effort_hours': 'sum'
    }).to_dict('index')
    
    return {
        severity: {
            'count': int(stats['vulnerability_id']),
            'total_risk': float(stats['predicted_risk']),
            'total_hours': float(stats['patch_effort_hours'])
        }
        for severity, stats in breakdown.items()
    }
