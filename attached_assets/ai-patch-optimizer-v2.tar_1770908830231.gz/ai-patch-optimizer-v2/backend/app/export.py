"""
Export Functionality
-------------------
Generate CSV and PDF reports from optimization results.
"""

import pandas as pd
from io import StringIO
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from io import BytesIO
from datetime import datetime


def generate_csv_export(results: dict) -> str:
    """Generate CSV export of optimization results"""
    if not results or 'selected_vulnerabilities' not in results:
        return ""
    
    df = pd.DataFrame(results['selected_vulnerabilities'])
    
    # Select relevant columns
    columns = [
        'vulnerability_id', 'cvss_score', 'exploit_available',
        'asset_criticality', 'days_since_disclosure',
        'patch_effort_hours', 'predicted_risk', 'confidence'
    ]
    
    # Filter to existing columns
    export_columns = [col for col in columns if col in df.columns]
    df_export = df[export_columns]
    
    # Convert to CSV
    output = StringIO()
    df_export.to_csv(output, index=False)
    return output.getvalue()


def generate_pdf_report(
    results: dict,
    vulnerability_data: pd.DataFrame,
    include_explanations: bool = False
) -> bytes:
    """Generate PDF report of optimization results"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1a202c'),
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        textColor=colors.HexColor('#2d3748'),
        spaceAfter=12,
        spaceBefore=12
    )
    
    # Title
    story.append(Paragraph("AI Patch Optimization Report", title_style))
    story.append(Paragraph(
        f"Generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p')}",
        styles['Normal']
    ))
    story.append(Spacer(1, 0.3 * inch))
    
    # Executive Summary
    story.append(Paragraph("Executive Summary", heading_style))
    
    summary_data = [
        ["Metric", "Value"],
        ["Total Vulnerabilities", str(results['total_vulnerabilities'])],
        ["Selected for Patching", str(results['selected_count'])],
        ["Total Risk Score", f"{results['total_risk']:.2f}"],
        ["Risk Reduced", f"{results['risk_reduced']:.2f}"],
        ["Risk Reduction %", f"{results['percentage_reduced']:.1f}%"],
        ["Hours Used", f"{results['hours_used']:.1f}"],
        ["Hours Available", f"{results['hours_available']:.1f}"],
        ["Average Confidence", f"{results.get('average_confidence', 0):.2%}"],
    ]
    
    summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4a5568')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f7fafc')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0'))
    ]))
    
    story.append(summary_table)
    story.append(Spacer(1, 0.3 * inch))
    
    # Business Impact
    if 'business_impact' in results:
        story.append(Paragraph("Business Impact", heading_style))
        impact = results['business_impact']
        story.append(Paragraph(impact['summary'], styles['Normal']))
        story.append(Spacer(1, 0.2 * inch))
    
    # Severity Breakdown
    if 'severity_breakdown' in results:
        story.append(Paragraph("Severity Breakdown", heading_style))
        
        severity_data = [["Severity", "Count", "Total Risk", "Hours Required"]]
        for severity in ['Critical', 'High', 'Medium', 'Low']:
            if severity in results['severity_breakdown']:
                stats = results['severity_breakdown'][severity]
                severity_data.append([
                    severity,
                    str(stats['count']),
                    f"{stats['total_risk']:.2f}",
                    f"{stats['total_hours']:.1f}"
                ])
        
        severity_table = Table(severity_data, colWidths=[1.5*inch, 1*inch, 1.5*inch, 1.5*inch])
        severity_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4a5568')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f7fafc')),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0'))
        ]))
        
        story.append(severity_table)
        story.append(Spacer(1, 0.3 * inch))
    
    # Selected Vulnerabilities
    story.append(PageBreak())
    story.append(Paragraph("Selected Vulnerabilities for Patching", heading_style))
    
    vulns = results['selected_vulnerabilities'][:20]  # Limit to first 20
    
    vuln_data = [["ID", "CVSS", "Risk", "Hours", "Confidence"]]
    for vuln in vulns:
        vuln_data.append([
            vuln['vulnerability_id'][:10],
            f"{vuln['cvss_score']:.1f}",
            f"{vuln['predicted_risk']:.2f}",
            f"{vuln['patch_effort_hours']:.1f}",
            f"{vuln.get('confidence', 0):.0%}"
        ])
    
    vuln_table = Table(vuln_data, colWidths=[1.5*inch, 1*inch, 1*inch, 1*inch, 1.2*inch])
    vuln_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4a5568')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f7fafc')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#f7fafc'), colors.white])
    ]))
    
    story.append(vuln_table)
    
    if len(results['selected_vulnerabilities']) > 20:
        story.append(Spacer(1, 0.2 * inch))
        story.append(Paragraph(
            f"Note: Showing top 20 of {len(results['selected_vulnerabilities'])} selected vulnerabilities. "
            "Download CSV for complete list.",
            styles['Italic']
        ))
    
    # Build PDF
    doc.build(story)
    
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes
