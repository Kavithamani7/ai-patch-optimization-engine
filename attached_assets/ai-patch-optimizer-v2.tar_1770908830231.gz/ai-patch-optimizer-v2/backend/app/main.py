"""
FastAPI Main Application - Production Grade
-------------------------------------------
Enhanced REST API with model comparison, SHAP explainability, 
export capabilities, and what-if analysis.

New Features:
- Model comparison (RF vs GBM)
- Global and local SHAP explanations
- CSV and PDF export
- What-if simulation
- Enhanced metrics and insights
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import pandas as pd
import numpy as np
from typing import Optional, List
from io import BytesIO
import json

from app.data import generate_vulnerability_data
from app.model import RiskPredictor, GradientBoostingPredictor
from app.optimizer import knapsack_optimize
from app.explain import get_shap_explanation, get_global_shap_explanation
from app.export import generate_csv_export, generate_pdf_report

# Initialize FastAPI app
app = FastAPI(
    title="AI Patch Optimization API",
    description="Production-grade API for vulnerability patch prioritization",
    version="2.0.0"
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global state
vulnerability_data: Optional[pd.DataFrame] = None
rf_model: Optional[RiskPredictor] = None
gbm_model: Optional[GradientBoostingPredictor] = None
active_model: Optional[str] = "random_forest"
optimization_results: Optional[dict] = None


# Request Models
class OptimizeRequest(BaseModel):
    available_patch_hours: float
    model_type: str = "random_forest"


class ExplainRequest(BaseModel):
    vulnerability_index: int


class WhatIfRequest(BaseModel):
    vulnerability_index: int
    cvss_score: Optional[float] = None
    exploit_available: Optional[int] = None
    asset_criticality: Optional[int] = None
    days_since_disclosure: Optional[int] = None


class ExportRequest(BaseModel):
    format: str  # "csv" or "pdf"
    include_explanations: bool = False


@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "message": "AI Patch Optimization API v2.0 is running",
        "version": "2.0.0",
        "features": [
            "Model Comparison",
            "SHAP Explainability",
            "CSV/PDF Export",
            "What-If Analysis"
        ]
    }


@app.post("/generate-data")
async def generate_data():
    """Generate synthetic vulnerability dataset"""
    global vulnerability_data
    
    try:
        vulnerability_data = generate_vulnerability_data(n_samples=1000)
        
        # Calculate severity distribution
        severity_counts = {
            "Critical": int((vulnerability_data['cvss_score'] >= 9.0).sum()),
            "High": int(((vulnerability_data['cvss_score'] >= 7.0) & 
                        (vulnerability_data['cvss_score'] < 9.0)).sum()),
            "Medium": int(((vulnerability_data['cvss_score'] >= 4.0) & 
                          (vulnerability_data['cvss_score'] < 7.0)).sum()),
            "Low": int((vulnerability_data['cvss_score'] < 4.0).sum())
        }
        
        return {
            "status": "success",
            "message": "Data generated successfully",
            "total_records": len(vulnerability_data),
            "severity_distribution": severity_counts,
            "statistics": {
                "mean_cvss": float(vulnerability_data['cvss_score'].mean()),
                "mean_risk": float(vulnerability_data['risk_score'].mean()),
                "total_patch_hours": float(vulnerability_data['patch_effort_hours'].sum()),
                "exploit_available_count": int(vulnerability_data['exploit_available'].sum())
            },
            "sample_data": vulnerability_data.head(10).to_dict('records')
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/train-models")
async def train_models():
    """Train both Random Forest and Gradient Boosting models"""
    global vulnerability_data, rf_model, gbm_model
    
    if vulnerability_data is None:
        raise HTTPException(
            status_code=400,
            detail="No data available. Please generate data first."
        )
    
    try:
        # Train Random Forest
        rf_model = RiskPredictor()
        rf_metrics = rf_model.train(vulnerability_data)
        
        # Train Gradient Boosting
        gbm_model = GradientBoostingPredictor()
        gbm_metrics = gbm_model.train(vulnerability_data)
        
        # Compare models
        comparison = {
            "random_forest": {
                **rf_metrics,
                "feature_importance": rf_model.get_feature_importance()
            },
            "gradient_boosting": {
                **gbm_metrics,
                "feature_importance": gbm_model.get_feature_importance()
            },
            "winner": "random_forest" if rf_metrics['r2'] > gbm_metrics['r2'] else "gradient_boosting"
        }
        
        return {
            "status": "success",
            "message": "Both models trained successfully",
            "comparison": comparison
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/optimize")
async def optimize(request: OptimizeRequest):
    """Run knapsack optimization with selected model"""
    global vulnerability_data, rf_model, gbm_model, active_model, optimization_results
    
    if vulnerability_data is None:
        raise HTTPException(
            status_code=400,
            detail="No data available. Please generate data first."
        )
    
    if rf_model is None or gbm_model is None:
        raise HTTPException(
            status_code=400,
            detail="Models not trained. Please train models first."
        )
    
    try:
        # Select active model
        active_model = request.model_type
        model = rf_model if request.model_type == "random_forest" else gbm_model
        
        # Predict risk scores
        predicted_risks = model.predict(vulnerability_data)
        
        # Add confidence scores (using prediction variance from tree-based models)
        if hasattr(model.model, 'estimators_'):
            predictions = np.array([
                estimator.predict(vulnerability_data[model.feature_columns])
                for estimator in model.model.estimators_
            ])
            confidence_scores = 1 - (predictions.std(axis=0) / predictions.mean(axis=0))
        else:
            confidence_scores = np.ones(len(predicted_risks)) * 0.85
        
        # Run optimization
        optimization_results = knapsack_optimize(
            vulnerability_data,
            predicted_risks,
            request.available_patch_hours,
            confidence_scores
        )
        
        # Add business impact summary
        optimization_results['business_impact'] = generate_business_impact(
            optimization_results,
            request.available_patch_hours
        )
        
        # Add risk heatmap data
        optimization_results['risk_heatmap'] = generate_risk_heatmap(
            vulnerability_data,
            predicted_risks
        )
        
        return {
            "status": "success",
            "message": "Optimization completed",
            "model_used": request.model_type,
            "results": optimization_results
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/explain/local")
async def explain_local(request: ExplainRequest):
    """Get local SHAP explanation for a specific vulnerability"""
    global vulnerability_data, rf_model, gbm_model, active_model
    
    if vulnerability_data is None or rf_model is None:
        raise HTTPException(
            status_code=400,
            detail="Please generate data and train models first."
        )
    
    if request.vulnerability_index >= len(vulnerability_data):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid index. Maximum index is {len(vulnerability_data) - 1}"
        )
    
    try:
        model = rf_model if active_model == "random_forest" else gbm_model
        explanation = get_shap_explanation(
            model.model,
            vulnerability_data,
            request.vulnerability_index,
            model.feature_columns
        )
        
        return {
            "status": "success",
            "explanation": explanation
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/explain/global")
async def explain_global():
    """Get global SHAP explanation (summary across all vulnerabilities)"""
    global vulnerability_data, rf_model, gbm_model, active_model
    
    if vulnerability_data is None or rf_model is None:
        raise HTTPException(
            status_code=400,
            detail="Please generate data and train models first."
        )
    
    try:
        model = rf_model if active_model == "random_forest" else gbm_model
        explanation = get_global_shap_explanation(
            model.model,
            vulnerability_data,
            model.feature_columns
        )
        
        return {
            "status": "success",
            "explanation": explanation
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/what-if")
async def what_if_analysis(request: WhatIfRequest):
    """Simulate risk prediction with modified features"""
    global vulnerability_data, rf_model, gbm_model, active_model
    
    if vulnerability_data is None or rf_model is None:
        raise HTTPException(
            status_code=400,
            detail="Please generate data and train models first."
        )
    
    try:
        model = rf_model if active_model == "random_forest" else gbm_model
        
        # Get original vulnerability
        original_vuln = vulnerability_data.iloc[request.vulnerability_index].copy()
        modified_vuln = original_vuln.copy()
        
        # Apply modifications
        if request.cvss_score is not None:
            modified_vuln['cvss_score'] = request.cvss_score
        if request.exploit_available is not None:
            modified_vuln['exploit_available'] = request.exploit_available
        if request.asset_criticality is not None:
            modified_vuln['asset_criticality'] = request.asset_criticality
        if request.days_since_disclosure is not None:
            modified_vuln['days_since_disclosure'] = request.days_since_disclosure
        
        # Predict with original and modified
        original_risk = model.predict(pd.DataFrame([original_vuln]))[0]
        modified_risk = model.predict(pd.DataFrame([modified_vuln]))[0]
        
        return {
            "status": "success",
            "original": {
                "features": original_vuln[model.feature_columns].to_dict(),
                "predicted_risk": float(original_risk)
            },
            "modified": {
                "features": modified_vuln[model.feature_columns].to_dict(),
                "predicted_risk": float(modified_risk)
            },
            "risk_change": float(modified_risk - original_risk),
            "risk_change_percentage": float((modified_risk - original_risk) / original_risk * 100)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/export/csv")
async def export_csv():
    """Export optimization results to CSV"""
    global optimization_results
    
    if optimization_results is None:
        raise HTTPException(
            status_code=400,
            detail="No optimization results available"
        )
    
    try:
        csv_data = generate_csv_export(optimization_results)
        
        return StreamingResponse(
            iter([csv_data.encode()]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=patch_optimization_results.csv"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/export/pdf")
async def export_pdf(request: ExportRequest):
    """Export optimization results to PDF report"""
    global optimization_results, vulnerability_data
    
    if optimization_results is None:
        raise HTTPException(
            status_code=400,
            detail="No optimization results available"
        )
    
    try:
        pdf_bytes = generate_pdf_report(
            optimization_results,
            vulnerability_data,
            include_explanations=request.include_explanations
        )
        
        return StreamingResponse(
            BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=patch_optimization_report.pdf"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def generate_business_impact(results: dict, available_hours: float) -> dict:
    """Generate business impact summary"""
    return {
        "summary": f"By optimizing patch deployment across {available_hours} hours, "
                  f"you can address {results['selected_count']} critical vulnerabilities, "
                  f"reducing total risk exposure by {results['percentage_reduced']:.1f}%. "
                  f"This represents {results['risk_reduced']:.0f} risk points mitigated.",
        "capacity_utilization": (results['hours_used'] / available_hours) * 100,
        "roi_estimate": results['risk_reduced'] / results['hours_used'] if results['hours_used'] > 0 else 0,
        "remaining_vulnerabilities": results['total_vulnerabilities'] - results['selected_count']
    }


def generate_risk_heatmap(df: pd.DataFrame, predicted_risks: np.ndarray) -> dict:
    """Generate risk heatmap data by CVSS and criticality"""
    df_copy = df.copy()
    df_copy['predicted_risk'] = predicted_risks
    
    # Create CVSS bins
    df_copy['cvss_bin'] = pd.cut(
        df_copy['cvss_score'],
        bins=[0, 4, 7, 9, 10],
        labels=['Low', 'Medium', 'High', 'Critical']
    )
    
    # Group by CVSS and criticality
    heatmap = df_copy.groupby(['cvss_bin', 'asset_criticality']).agg({
        'predicted_risk': 'mean',
        'vulnerability_id': 'count'
    }).reset_index()
    
    return {
        "data": heatmap.to_dict('records'),
        "x_labels": ["Low", "Medium", "High", "Very High", "Critical"],
        "y_labels": ["Low", "Medium", "High", "Critical"]
    }
