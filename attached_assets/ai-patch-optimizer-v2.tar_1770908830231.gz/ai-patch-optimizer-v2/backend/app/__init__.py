"""
AI Patch Optimization Backend
-----------------------------
Production-grade vulnerability patch optimization system.
"""

__version__ = "2.0.0"
