"""
Data Generation Module
----------------------
This module generates synthetic vulnerability data for the patch optimization system.

It creates realistic vulnerability records with various features that affect risk scoring:
- CVSS scores (industry standard vulnerability severity metric)
- Exploit availability (whether exploit code exists in the wild)
- Asset criticality (how important the affected system is)
- Patch effort (estimated hours to apply the patch)
- Days since disclosure (age of vulnerability)
"""

import pandas as pd
import numpy as np


def generate_vulnerability_data(n_samples: int = 1000) -> pd.DataFrame:
    """
    Generate synthetic vulnerability dataset.
    
    Args:
        n_samples: Number of vulnerability records to generate
        
    Returns:
        DataFrame with vulnerability features and calculated risk scores
    """
    np.random.seed(42)  # For reproducibility
    
    # Generate feature data
    # CVSS scores range from 0-10, with higher being more severe
    cvss_scores = np.random.uniform(3, 10, n_samples)
    
    # Binary flag: 1 if exploit code is publicly available, 0 otherwise
    exploit_available = np.random.choice([0, 1], n_samples, p=[0.6, 0.4])
    
    # Asset criticality: 1=Low, 2=Medium, 3=High, 4=Critical
    asset_criticality = np.random.choice([1, 2, 3, 4], n_samples, p=[0.2, 0.3, 0.3, 0.2])
    
    # Estimated hours to patch (complexity of applying the fix)
    patch_effort_hours = np.random.uniform(0.5, 8, n_samples)
    
    # Days since the vulnerability was publicly disclosed
    days_since_disclosure = np.random.randint(1, 365, n_samples)
    
    # Calculate contextual risk score
    # This formula weights multiple factors to create a realistic risk metric:
    # - Base CVSS score (40% weight)
    # - Exploit availability doubles impact if present
    # - Asset criticality multiplier
    # - Time urgency (older vulnerabilities slightly less urgent)
    risk_score = (
        cvss_scores * 4 +  # Base severity
        exploit_available * 15 +  # Exploit availability is critical
        asset_criticality * 5 +  # Business impact
        (365 - days_since_disclosure) / 365 * 10  # Time decay factor
    )
    
    # Create DataFrame
    df = pd.DataFrame({
        'vulnerability_id': [f'CVE-2024-{1000 + i}' for i in range(n_samples)],
        'cvss_score': cvss_scores,
        'exploit_available': exploit_available,
        'asset_criticality': asset_criticality,
        'patch_effort_hours': patch_effort_hours,
        'days_since_disclosure': days_since_disclosure,
        'risk_score': risk_score
    })
    
    return df
