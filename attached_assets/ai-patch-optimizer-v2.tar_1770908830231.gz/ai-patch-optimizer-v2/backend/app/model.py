"""
Enhanced Machine Learning Models
--------------------------------
Supports both Random Forest and Gradient Boosting for comparison.
Includes feature importance extraction and prediction confidence.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error


class RiskPredictor:
    """Random Forest risk prediction model"""
    
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1
        )
        self.feature_columns = [
            'cvss_score',
            'exploit_available', 
            'asset_criticality',
            'days_since_disclosure'
        ]
        
    def train(self, df: pd.DataFrame) -> dict:
        """Train Random Forest model"""
        X = df[self.feature_columns]
        y = df['risk_score']
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)
        
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        
        return {
            'rmse': float(rmse),
            'r2': float(r2),
            'mae': float(mae),
            'train_samples': len(X_train),
            'test_samples': len(X_test)
        }
    
    def predict(self, df: pd.DataFrame) -> np.ndarray:
        """Predict risk scores"""
        X = df[self.feature_columns]
        return self.model.predict(X)
    
    def get_feature_importance(self) -> dict:
        """Get feature importance scores"""
        importance = self.model.feature_importances_
        return {
            feature: float(imp) 
            for feature, imp in zip(self.feature_columns, importance)
        }


class GradientBoostingPredictor:
    """Gradient Boosting risk prediction model"""
    
    def __init__(self):
        self.model = GradientBoostingRegressor(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        self.feature_columns = [
            'cvss_score',
            'exploit_available', 
            'asset_criticality',
            'days_since_disclosure'
        ]
        
    def train(self, df: pd.DataFrame) -> dict:
        """Train Gradient Boosting model"""
        X = df[self.feature_columns]
        y = df['risk_score']
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)
        
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        
        return {
            'rmse': float(rmse),
            'r2': float(r2),
            'mae': float(mae),
            'train_samples': len(X_train),
            'test_samples': len(X_test)
        }
    
    def predict(self, df: pd.DataFrame) -> np.ndarray:
        """Predict risk scores"""
        X = df[self.feature_columns]
        return self.model.predict(X)
    
    def get_feature_importance(self) -> dict:
        """Get feature importance scores"""
        importance = self.model.feature_importances_
        return {
            feature: float(imp) 
            for feature, imp in zip(self.feature_columns, importance)
        }
