"""
SHAP Explainability Module
--------------------------
Provides both local and global SHAP explanations with multiple visualization types.
"""

import pandas as pd
import numpy as np
import shap
from typing import List


def get_shap_explanation(model, df: pd.DataFrame, index: int, feature_columns: List[str]) -> dict:
    """
    Get local SHAP explanation for a specific vulnerability.
    Returns bar chart and waterfall data.
    """
    try:
        X = df[feature_columns]
        
        # Create SHAP explainer
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X)
        
        # Get SHAP values for the specific instance
        instance_shap = shap_values[index]
        instance_features = X.iloc[index]
        base_value = explainer.expected_value
        
        # Sort features by absolute SHAP value
        feature_importance = sorted(
            zip(feature_columns, instance_shap, instance_features),
            key=lambda x: abs(x[1]),
            reverse=True
        )
        
        # Prepare bar chart data
        bar_data = {
            "features": [f[0] for f in feature_importance],
            "shap_values": [float(f[1]) for f in feature_importance],
            "feature_values": [float(f[2]) for f in feature_importance]
        }
        
        # Prepare waterfall data
        waterfall_data = {
            "base_value": float(base_value),
            "features": [
                {
                    "name": f[0],
                    "shap_value": float(f[1]),
                    "feature_value": float(f[2])
                }
                for f in feature_importance
            ],
            "final_prediction": float(base_value + sum(instance_shap))
        }
        
        return {
            "vulnerability_index": index,
            "bar_chart": bar_data,
            "waterfall": waterfall_data,
            "feature_contributions": {
                f[0]: {
                    "shap_value": float(f[1]),
                    "feature_value": float(f[2]),
                    "impact": "Increases risk" if f[1] > 0 else "Decreases risk"
                }
                for f in feature_importance
            }
        }
    except Exception as e:
        raise Exception(f"Error generating SHAP explanation: {str(e)}")


def get_global_shap_explanation(model, df: pd.DataFrame, feature_columns: List[str]) -> dict:
    """
    Get global SHAP explanation across all vulnerabilities.
    Returns summary plot data and feature importance rankings.
    """
    try:
        X = df[feature_columns]
        
        # Create SHAP explainer
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X)
        
        # Calculate mean absolute SHAP values for feature importance
        mean_abs_shap = np.abs(shap_values).mean(axis=0)
        
        # Sort features by importance
        feature_importance = sorted(
            zip(feature_columns, mean_abs_shap),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Prepare summary plot data (beeswarm-style)
        summary_data = []
        for i, feature in enumerate(feature_columns):
            feature_values = X[feature].values
            feature_shap = shap_values[:, i]
            
            # Sample points for visualization (max 100 points per feature)
            sample_size = min(100, len(feature_values))
            indices = np.random.choice(len(feature_values), sample_size, replace=False)
            
            summary_data.append({
                "feature": feature,
                "mean_abs_shap": float(mean_abs_shap[i]),
                "points": [
                    {
                        "shap_value": float(feature_shap[idx]),
                        "feature_value": float(feature_values[idx])
                    }
                    for idx in indices
                ]
            })
        
        # Feature importance ranking
        importance_ranking = [
            {
                "feature": f[0],
                "importance": float(f[1]),
                "rank": idx + 1
            }
            for idx, f in enumerate(feature_importance)
        ]
        
        # Calculate feature interactions
        interactions = calculate_feature_interactions(shap_values, feature_columns)
        
        return {
            "summary_plot": summary_data,
            "feature_importance": importance_ranking,
            "feature_interactions": interactions,
            "total_samples": len(df)
        }
    except Exception as e:
        raise Exception(f"Error generating global SHAP explanation: {str(e)}")


def calculate_feature_interactions(shap_values: np.ndarray, feature_columns: List[str]) -> dict:
    """Calculate pairwise feature interactions"""
    n_features = len(feature_columns)
    interactions = []
    
    for i in range(n_features):
        for j in range(i + 1, n_features):
            # Calculate correlation between SHAP values
            correlation = np.corrcoef(shap_values[:, i], shap_values[:, j])[0, 1]
            
            if abs(correlation) > 0.3:  # Only include significant interactions
                interactions.append({
                    "feature1": feature_columns[i],
                    "feature2": feature_columns[j],
                    "correlation": float(correlation),
                    "strength": "Strong" if abs(correlation) > 0.6 else "Moderate"
                })
    
    return sorted(interactions, key=lambda x: abs(x['correlation']), reverse=True)
