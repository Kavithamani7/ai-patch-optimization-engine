/**
 * API Service Module
 * Handles all backend communication
 */

const API_BASE_URL = 'http://localhost:8000';

// Helper function for API calls
async function apiCall(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.statusText}`);
  }

  return response.json();
}

export async function generateData() {
  return apiCall('/generate-data', { method: 'POST' });
}

export async function trainModels() {
  return apiCall('/train-models', { method: 'POST' });
}

export async function optimize(hours: number, modelType: string = 'random_forest') {
  return apiCall('/optimize', {
    method: 'POST',
    body: JSON.stringify({
      available_patch_hours: hours,
      model_type: modelType
    }),
  });
}

export async function getLocalExplanation(index: number) {
  return apiCall('/explain/local', {
    method: 'POST',
    body: JSON.stringify({
      vulnerability_index: index
    }),
  });
}

export async function getGlobalExplanation() {
  return apiCall('/explain/global', { method: 'POST' });
}

export async function whatIfAnalysis(
  index: number,
  modifications: {
    cvss_score?: number;
    exploit_available?: number;
    asset_criticality?: number;
    days_since_disclosure?: number;
  }
) {
  return apiCall('/what-if', {
    method: 'POST',
    body: JSON.stringify({
      vulnerability_index: index,
      ...modifications
    }),
  });
}

export async function exportCSV() {
  const response = await fetch(`${API_BASE_URL}/export/csv`);
  
  if (!response.ok) {
    throw new Error('Export failed');
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'patch_optimization_results.csv';
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

export async function exportPDF(includeExplanations: boolean = false) {
  const response = await fetch(`${API_BASE_URL}/export/pdf`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      format: 'pdf',
      include_explanations: includeExplanations
    }),
  });

  if (!response.ok) {
    throw new Error('Export failed');
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'patch_optimization_report.pdf';
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
