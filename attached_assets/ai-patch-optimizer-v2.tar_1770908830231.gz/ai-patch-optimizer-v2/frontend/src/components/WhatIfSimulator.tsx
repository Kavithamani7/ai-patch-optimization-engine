import React, { useState } from 'react';
import { WhatIfResult } from '../types';

interface WhatIfSimulatorProps {
  vulnerabilityIndex: number;
  vulnerability: any;
  onSimulate: (index: number, modifications: any) => void;
  onClose: () => void;
  result: WhatIfResult | null;
}

const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = ({
  vulnerabilityIndex,
  vulnerability,
  onSimulate,
  onClose,
  result
}) => {
  const [cvssScore, setCvssScore] = useState(vulnerability.cvss_score.toString());
  const [exploitAvailable, setExploitAvailable] = useState(vulnerability.exploit_available.toString());
  const [assetCriticality, setAssetCriticality] = useState(vulnerability.asset_criticality.toString());
  const [daysSince, setDaysSince] = useState(vulnerability.days_since_disclosure.toString());
  
  const handleSimulate = () => {
    const modifications: any = {};
    
    if (parseFloat(cvssScore) !== vulnerability.cvss_score) {
      modifications.cvss_score = parseFloat(cvssScore);
    }
    if (parseInt(exploitAvailable) !== vulnerability.exploit_available) {
      modifications.exploit_available = parseInt(exploitAvailable);
    }
    if (parseInt(assetCriticality) !== vulnerability.asset_criticality) {
      modifications.asset_criticality = parseInt(assetCriticality);
    }
    if (parseInt(daysSince) !== vulnerability.days_since_disclosure) {
      modifications.days_since_disclosure = parseInt(daysSince);
    }
    
    onSimulate(vulnerabilityIndex, modifications);
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
        <div className="bg-purple-600 text-white p-6 rounded-t-lg">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">What-If Simulation</h2>
            <button onClick={onClose} className="text-white hover:text-gray-200">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <p className="text-sm text-purple-100 mt-2">
            Modify vulnerability features to see how risk prediction changes
          </p>
        </div>
        
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                CVSS Score (0-10)
              </label>
              <input
                type="number"
                value={cvssScore}
                onChange={(e) => setCvssScore(e.target.value)}
                min="0"
                max="10"
                step="0.1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Exploit Available (0/1)
              </label>
              <select
                value={exploitAvailable}
                onChange={(e) => setExploitAvailable(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              >
                <option value="0">No</option>
                <option value="1">Yes</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Asset Criticality (1-4)
              </label>
              <select
                value={assetCriticality}
                onChange={(e) => setAssetCriticality(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              >
                <option value="1">1 - Low</option>
                <option value="2">2 - Medium</option>
                <option value="3">3 - High</option>
                <option value="4">4 - Critical</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Days Since Disclosure
              </label>
              <input
                type="number"
                value={daysSince}
                onChange={(e) => setDaysSince(e.target.value)}
                min="0"
                step="1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>
          
          <button
            onClick={handleSimulate}
            className="w-full bg-purple-600 text-white py-3 rounded-lg font-medium hover:bg-purple-700"
          >
            Run Simulation
          </button>
          
          {result && (
            <div className="mt-6 p-4 bg-gray-50 rounded-lg space-y-3">
              <h3 className="font-semibold text-gray-900">Simulation Results</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded">
                  <p className="text-xs text-gray-600 mb-1">Original Risk</p>
                  <p className="text-xl font-bold text-gray-900">
                    {result.original.predicted_risk.toFixed(3)}
                  </p>
                </div>
                
                <div className="bg-white p-3 rounded">
                  <p className="text-xs text-gray-600 mb-1">Modified Risk</p>
                  <p className="text-xl font-bold text-gray-900">
                    {result.modified.predicted_risk.toFixed(3)}
                  </p>
                </div>
              </div>
              
              <div className={`p-3 rounded ${
                result.risk_change > 0 ? 'bg-red-50' : 'bg-green-50'
              }`}>
                <p className="text-sm font-medium mb-1">
                  Risk Change: 
                  <span className={`ml-2 font-bold ${
                    result.risk_change > 0 ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {result.risk_change > 0 ? '+' : ''}{result.risk_change.toFixed(3)} 
                    ({result.risk_change_percentage > 0 ? '+' : ''}{result.risk_change_percentage.toFixed(1)}%)
                  </span>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WhatIfSimulator;
