import React from 'react';
import { ModelComparison } from '../types';

interface ModelComparisonCardProps {
  comparison: ModelComparison;
}

const ModelComparisonCard: React.FC<ModelComparisonCardProps> = ({ comparison }) => {
  const models = [
    { name: 'Random Forest', key: 'random_forest' as const, color: 'blue' },
    { name: 'Gradient Boosting', key: 'gradient_boosting' as const, color: 'green' }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Model Comparison</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {models.map(model => {
          const metrics = comparison[model.key];
          const isWinner = comparison.winner === model.key;
          
          return (
            <div key={model.key} className={`
              p-4 rounded-lg border-2 transition-all
              ${isWinner ? 'border-green-500 bg-green-50' : 'border-gray-200'}
            `}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-gray-900">{model.name}</h3>
                {isWinner && (
                  <span className="px-2 py-1 bg-green-500 text-white text-xs font-medium rounded">
                    Best Model
                  </span>
                )}
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">R² Score:</span>
                  <span className="font-semibold">{metrics.r2.toFixed(4)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">RMSE:</span>
                  <span className="font-semibold">{metrics.rmse.toFixed(3)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">MAE:</span>
                  <span className="font-semibold">{metrics.mae.toFixed(3)}</span>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-xs text-gray-600 font-medium mb-2">Feature Importance:</p>
                {Object.entries(metrics.feature_importance)
                  .sort(([,a], [,b]) => (b as number) - (a as number))
                  .map(([feature, importance]) => (
                    <div key={feature} className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-gray-600 w-32 truncate">{feature}</span>
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${(importance as number) * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 w-12 text-right">
                        {((importance as number) * 100).toFixed(1)}%
                      </span>
                    </div>
                  ))
                }
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ModelComparisonCard;
