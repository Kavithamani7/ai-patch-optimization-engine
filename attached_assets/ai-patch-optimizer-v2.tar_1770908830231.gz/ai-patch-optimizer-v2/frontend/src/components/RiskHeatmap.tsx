import React from 'react';
import { RiskHeatmapData } from '../types';

interface RiskHeatmapProps {
  data: RiskHeatmapData;
}

const RiskHeatmap: React.FC<RiskHeatmapProps> = ({ data }) => {
  const severityLevels = ['Low', 'Medium', 'High', 'Critical'];
  const criticalityLevels = [1, 2, 3, 4];
  
  const getRiskColor = (risk: number) => {
    if (risk >= 8) return 'bg-red-600';
    if (risk >= 6) return 'bg-orange-500';
    if (risk >= 4) return 'bg-yellow-400';
    return 'bg-green-400';
  };
  
  const getRiskData = (severity: string, criticality: number) => {
    const entry = data.data.find(d => 
      d.cvss_bin === severity && d.asset_criticality === criticality
    );
    return entry ? entry.predicted_risk : 0;
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Risk Heatmap</h2>
      <p className="text-sm text-gray-600 mb-4">
        Average predicted risk by CVSS severity and asset criticality
      </p>
      
      <div className="overflow-x-auto">
        <div className="inline-block min-w-full">
          <div className="flex gap-2">
            <div className="flex flex-col justify-end pb-8">
              <div className="text-xs font-medium text-gray-700 transform -rotate-90 origin-center whitespace-nowrap">
                Asset Criticality
              </div>
            </div>
            
            <div>
              <div className="grid gap-1" style={{ 
                gridTemplateColumns: `80px repeat(${severityLevels.length}, 80px)` 
              }}>
                <div></div>
                {severityLevels.map(severity => (
                  <div key={severity} className="text-xs font-medium text-gray-700 text-center py-2">
                    {severity}
                  </div>
                ))}
                
                {criticalityLevels.map(criticality => (
                  <React.Fragment key={criticality}>
                    <div className="text-xs font-medium text-gray-700 flex items-center pr-2">
                      {['Low', 'Medium', 'High', 'Critical'][criticality - 1]}
                    </div>
                    {severityLevels.map(severity => {
                      const risk = getRiskData(severity, criticality);
                      return (
                        <div
                          key={`${severity}-${criticality}`}
                          className={`h-16 rounded flex items-center justify-center text-white font-semibold ${getRiskColor(risk)}`}
                          title={`${severity} / Criticality ${criticality}: ${risk.toFixed(2)}`}
                        >
                          {risk > 0 ? risk.toFixed(1) : '-'}
                        </div>
                      );
                    })}
                  </React.Fragment>
                ))}
              </div>
              
              <div className="text-xs text-center text-gray-700 mt-2">
                CVSS Severity
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-4 flex items-center gap-4 text-xs">
        <span className="text-gray-600">Risk Level:</span>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-green-400 rounded"></div>
            <span>Low</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-yellow-400 rounded"></div>
            <span>Medium</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-orange-500 rounded"></div>
            <span>High</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-red-600 rounded"></div>
            <span>Critical</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiskHeatmap;
