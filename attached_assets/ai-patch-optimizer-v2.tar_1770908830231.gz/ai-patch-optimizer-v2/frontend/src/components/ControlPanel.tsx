import React from 'react';

interface ControlPanelProps {
  dataGenerated: boolean;
  modelsTrained: boolean;
  loading: boolean;
  patchHours: string;
  selectedModel: 'random_forest' | 'gradient_boosting';
  onGenerateData: () => void;
  onTrainModels: () => void;
  onOptimize: () => void;
  onPatchHoursChange: (value: string) => void;
  onModelChange: (model: 'random_forest' | 'gradient_boosting') => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  dataGenerated,
  modelsTrained,
  loading,
  patchHours,
  selectedModel,
  onGenerateData,
  onTrainModels,
  onOptimize,
  onPatchHoursChange,
  onModelChange
}) => {
  return (
    <div className="space-y-6">
      {/* Main Controls */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <svg className="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} 
              d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
          </svg>
          Workflow Controls
        </h2>
        
        <div className="space-y-4">
          {/* Step 1: Generate Data */}
          <div>
            <button
              onClick={onGenerateData}
              disabled={loading}
              className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading && !dataGenerated ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Generating...
                </span>
              ) : '1. Generate Data'}
            </button>
            {dataGenerated && (
              <div className="mt-2 flex items-center text-sm text-green-600">
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Data ready (1000 records)
              </div>
            )}
          </div>

          {/* Step 2: Train Models */}
          <div>
            <button
              onClick={onTrainModels}
              disabled={loading || !dataGenerated}
              className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading && dataGenerated && !modelsTrained ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Training...
                </span>
              ) : '2. Train Models'}
            </button>
            {modelsTrained && (
              <div className="mt-2 flex items-center text-sm text-green-600">
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Models trained
              </div>
            )}
          </div>

          {/* Model Selection */}
          {modelsTrained && (
            <div className="pt-4 border-t border-gray-200">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Model
              </label>
              <select
                value={selectedModel}
                onChange={(e) => onModelChange(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="random_forest">Random Forest</option>
                <option value="gradient_boosting">Gradient Boosting</option>
              </select>
            </div>
          )}

          {/* Patch Hours Input */}
          <div className="pt-4 border-t border-gray-200">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Available Patch Hours
            </label>
            <input
              type="number"
              value={patchHours}
              onChange={(e) => onPatchHoursChange(e.target.value)}
              min="1"
              step="0.5"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., 40"
            />
            <p className="mt-1 text-xs text-gray-500">Maximum hours for patching</p>
          </div>

          {/* Step 3: Optimize */}
          <div>
            <button
              onClick={onOptimize}
              disabled={loading || !modelsTrained}
              className="w-full btn-success disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading && modelsTrained ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Optimizing...
                </span>
              ) : '3. Optimize Patches'}
            </button>
          </div>
        </div>
      </div>

      {/* Info Card */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-blue-900 mb-2 flex items-center">
          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          How it works
        </h3>
        <ol className="text-xs text-blue-800 space-y-2">
          <li>1. Generate synthetic vulnerability data</li>
          <li>2. Train and compare ML models (RF vs GBM)</li>
          <li>3. Optimize patch selection with constraints</li>
          <li>4. Explore SHAP explanations and simulate scenarios</li>
        </ol>
      </div>
    </div>
  );
};

export default ControlPanel;
