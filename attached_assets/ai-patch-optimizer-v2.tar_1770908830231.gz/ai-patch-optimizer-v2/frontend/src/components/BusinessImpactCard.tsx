import React from 'react';
import { BusinessImpact } from '../types';

interface BusinessImpactCardProps {
  impact: BusinessImpact;
}

const BusinessImpactCard: React.FC<BusinessImpactCardProps> = ({ impact }) => {
  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg shadow-sm border border-blue-200 p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <svg className="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} 
            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
        Business Impact Summary
      </h2>
      
      <p className="text-gray-700 mb-6 leading-relaxed">{impact.summary}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <p className="text-sm text-gray-600 mb-1">Capacity Utilization</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-blue-600">
              {impact.capacity_utilization.toFixed(1)}%
            </p>
          </div>
          <div className="mt-2 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all"
              style={{ width: `${Math.min(impact.capacity_utilization, 100)}%` }}
            />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <p className="text-sm text-gray-600 mb-1">ROI Estimate</p>
          <p className="text-2xl font-bold text-green-600">
            {impact.roi_estimate.toFixed(2)}
          </p>
          <p className="text-xs text-gray-500 mt-1">Risk points per hour</p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <p className="text-sm text-gray-600 mb-1">Remaining Vulnerabilities</p>
          <p className="text-2xl font-bold text-orange-600">
            {impact.remaining_vulnerabilities}
          </p>
          <p className="text-xs text-gray-500 mt-1">Require future attention</p>
        </div>
      </div>
    </div>
  );
};

export default BusinessImpactCard;
