import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-gray-600">
            <p>AI Patch Optimizer v2.0 - Production Grade</p>
            <p className="text-xs text-gray-500 mt-1">
              Built with React + TypeScript + FastAPI + scikit-learn + SHAP
            </p>
          </div>
          
          <div className="flex items-center gap-6 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Backend: Connected</span>
            </div>
            <div className="text-xs">
              <span className="font-medium">System:</span> localhost:8000
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
