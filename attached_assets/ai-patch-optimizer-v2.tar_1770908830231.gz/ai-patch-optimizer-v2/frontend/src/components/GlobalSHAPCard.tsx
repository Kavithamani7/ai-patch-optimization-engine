import React from 'react';
import { GlobalSHAPExplanation } from '../types';

interface GlobalSHAPCardProps {
  explanation: GlobalSHAPExplanation;
  onClose: () => void;
}

const GlobalSHAPCard: React.FC<GlobalSHAPCardProps> = ({ explanation, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-900">Global Feature Importance</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="p-6 space-y-6">
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Feature Importance Ranking</h3>
            <p className="text-sm text-gray-600 mb-4">
              Based on mean absolute SHAP values across {explanation.total_samples} samples
            </p>
            
            {explanation.feature_importance.map((feature, idx) => (
              <div key={feature.feature} className="mb-3">
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">
                    #{feature.rank} {feature.feature}
                  </span>
                  <span className="text-gray-600">
                    Importance: {feature.importance.toFixed(4)}
                  </span>
                </div>
                <div className="bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-gradient-to-r from-blue-600 to-blue-400 h-3 rounded-full"
                    style={{ width: `${(feature.importance / explanation.feature_importance[0].importance) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          
          {explanation.feature_interactions.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Feature Interactions</h3>
              <p className="text-sm text-gray-600 mb-4">
                Significant correlations between feature SHAP values
              </p>
              
              <div className="space-y-2">
                {explanation.feature_interactions.map((interaction, idx) => (
                  <div key={idx} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="font-medium">{interaction.feature1}</span>
                        <span className="mx-2 text-gray-400">↔</span>
                        <span className="font-medium">{interaction.feature2}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 text-xs font-medium rounded ${
                          interaction.strength === 'Strong' 
                            ? 'bg-red-100 text-red-700' 
                            : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {interaction.strength}
                        </span>
                        <span className="text-sm text-gray-600">
                          r = {interaction.correlation.toFixed(3)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GlobalSHAPCard;
