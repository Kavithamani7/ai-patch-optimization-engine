import React, { useState } from 'react';
import { SHAPExplanation } from '../types';

interface SHAPExplanationCardProps {
  explanation: SHAPExplanation;
  vulnerabilityIndex: number | null;
}

const SHAPExplanationCard: React.FC<SHAPExplanationCardProps> = ({ explanation, vulnerabilityIndex }) => {
  const [viewType, setViewType] = useState<'bar' | 'waterfall'>('bar');
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900">
          SHAP Explanation - Vulnerability #{vulnerabilityIndex !== null ? vulnerabilityIndex : explanation.vulnerability_index}
        </h2>
        <div className="flex gap-2">
          <button
            onClick={() => setViewType('bar')}
            className={`px-3 py-1 text-sm rounded ${
              viewType === 'bar' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-200 text-gray-700'
            }`}
          >
            Bar Chart
          </button>
          <button
            onClick={() => setViewType('waterfall')}
            className={`px-3 py-1 text-sm rounded ${
              viewType === 'waterfall' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-200 text-gray-700'
            }`}
          >
            Waterfall
          </button>
        </div>
      </div>
      
      {viewType === 'bar' ? (
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            Feature contributions to the predicted risk (SHAP values)
          </p>
          {explanation.bar_chart.features.map((feature, idx) => {
            const shapValue = explanation.bar_chart.shap_values[idx];
            const featureValue = explanation.bar_chart.feature_values[idx];
            const isPositive = shapValue > 0;
            
            return (
              <div key={feature} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{feature}</span>
                  <span className="text-gray-600">Value: {featureValue.toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-200 rounded-full h-6 relative overflow-hidden">
                    <div
                      className={`h-6 rounded-full ${isPositive ? 'bg-red-500' : 'bg-blue-500'}`}
                      style={{
                        width: `${Math.min(Math.abs(shapValue) * 10, 100)}%`,
                        marginLeft: isPositive ? '50%' : `${50 - Math.min(Math.abs(shapValue) * 10, 50)}%`
                      }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xs font-semibold text-white">
                        {shapValue > 0 ? '+' : ''}{shapValue.toFixed(3)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-gray-600 mb-4">
            Waterfall showing how features contribute to the final prediction
          </p>
          <div className="space-y-2">
            <div className="flex justify-between py-2 px-3 bg-gray-50 rounded">
              <span className="font-medium">Base Value</span>
              <span className="font-semibold">{explanation.waterfall.base_value.toFixed(3)}</span>
            </div>
            
            {explanation.waterfall.features.map((feature, idx) => (
              <div key={idx} className="flex justify-between py-2 px-3 border-l-4 rounded"
                style={{
                  borderColor: feature.shap_value > 0 ? '#ef4444' : '#3b82f6',
                  backgroundColor: feature.shap_value > 0 ? '#fee2e2' : '#dbeafe'
                }}>
                <div>
                  <span className="font-medium">{feature.name}</span>
                  <span className="text-xs text-gray-600 ml-2">({feature.feature_value.toFixed(2)})</span>
                </div>
                <span className={`font-semibold ${
                  feature.shap_value > 0 ? 'text-red-600' : 'text-blue-600'
                }`}>
                  {feature.shap_value > 0 ? '+' : ''}{feature.shap_value.toFixed(3)}
                </span>
              </div>
            ))}
            
            <div className="flex justify-between py-2 px-3 bg-green-50 rounded border-2 border-green-500">
              <span className="font-bold">Final Prediction</span>
              <span className="font-bold text-green-700">
                {explanation.waterfall.final_prediction.toFixed(3)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SHAPExplanationCard;
