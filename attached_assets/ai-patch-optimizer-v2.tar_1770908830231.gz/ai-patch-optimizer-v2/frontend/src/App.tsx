/**
 * Production-Grade AI Patch Optimizer Dashboard
 * ---------------------------------------------
 * Features:
 * - Workflow-based UX with progress tracking
 * - Model comparison (RF vs GBM)
 * - Global and local SHAP explanations
 * - Risk heatmap visualization
 * - What-if simulation
 * - CSV/PDF export
 * - Clean, modular component architecture
 */

import React, { useState } from 'react';
import { 
  generateData, 
  trainModels, 
  optimize, 
  getLocalExplanation,
  getGlobalExplanation,
  whatIfAnalysis,
  exportCSV,
  exportPDF
} from './services/api';
import {
  OptimizationResult,
  ModelComparison,
  SHAPExplanation,
  GlobalSHAPExplanation,
  WhatIfResult
} from './types';

// Components
import Header from './components/Header';
import ProgressTracker from './components/ProgressTracker';
import ControlPanel from './components/ControlPanel';
import MetricsGrid from './components/MetricsGrid';
import ModelComparisonCard from './components/ModelComparisonCard';
import VulnerabilityTable from './components/VulnerabilityTable';
import RiskHeatmap from './components/RiskHeatmap';
import SHAPExplanationCard from './components/SHAPExplanationCard';
import GlobalSHAPCard from './components/GlobalSHAPCard';
import WhatIfSimulator from './components/WhatIfSimulator';
import BusinessImpactCard from './components/BusinessImpactCard';
import ExportPanel from './components/ExportPanel';
import Footer from './components/Footer';
import NotificationToast from './components/NotificationToast';
import LoadingOverlay from './components/LoadingOverlay';

interface Notification {
  type: 'success' | 'error' | 'info';
  message: string;
}

function App() {
  // Workflow state
  const [currentStep, setCurrentStep] = useState(0);
  const [dataGenerated, setDataGenerated] = useState(false);
  const [modelsTrained, setModelsTrained] = useState(false);
  const [optimizationRun, setOptimizationRun] = useState(false);
  
  // Loading states
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  
  // Data state
  const [patchHours, setPatchHours] = useState<string>('40');
  const [selectedModel, setSelectedModel] = useState<'random_forest' | 'gradient_boosting'>('random_forest');
  const [modelComparison, setModelComparison] = useState<ModelComparison | null>(null);
  const [optimizationResults, setOptimizationResults] = useState<OptimizationResult | null>(null);
  const [localShapExplanation, setLocalShapExplanation] = useState<SHAPExplanation | null>(null);
  const [globalShapExplanation, setGlobalShapExplanation] = useState<GlobalSHAPExplanation | null>(null);
  const [whatIfResult, setWhatIfResult] = useState<WhatIfResult | null>(null);
  
  // UI state
  const [notification, setNotification] = useState<Notification | null>(null);
  const [showGlobalShap, setShowGlobalShap] = useState(false);
  const [showWhatIf, setShowWhatIf] = useState(false);
  const [selectedVulnIndex, setSelectedVulnIndex] = useState<number | null>(null);

  // Notification helper
  const showNotification = (type: Notification['type'], message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  // Step 1: Generate Data
  const handleGenerateData = async () => {
    setLoading(true);
    setLoadingMessage('Generating synthetic vulnerability dataset...');
    
    try {
      const response = await generateData();
      setDataGenerated(true);
      setCurrentStep(1);
      setModelsTrained(false);
      setOptimizationRun(false);
      setOptimizationResults(null);
      setLocalShapExplanation(null);
      setGlobalShapExplanation(null);
      
      showNotification('success', 
        `Generated ${response.total_records} vulnerabilities with ${response.severity_distribution.Critical} critical issues`
      );
    } catch (error) {
      showNotification('error', 'Failed to generate data. Ensure backend is running on port 8000.');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // Step 2: Train Models
  const handleTrainModels = async () => {
    if (!dataGenerated) {
      showNotification('error', 'Please generate data first!');
      return;
    }
    
    setLoading(true);
    setLoadingMessage('Training Random Forest and Gradient Boosting models...');
    
    try {
      const response = await trainModels();
      setModelComparison(response.comparison);
      setModelsTrained(true);
      setCurrentStep(2);
      setOptimizationRun(false);
      
      const winner = response.comparison.winner === 'random_forest' ? 'Random Forest' : 'Gradient Boosting';
      const winnerR2 = response.comparison[response.comparison.winner].r2;
      
      showNotification('success', 
        `Models trained! ${winner} performs best with R² = ${winnerR2.toFixed(3)}`
      );
    } catch (error) {
      showNotification('error', 'Failed to train models.');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // Step 3: Run Optimization
  const handleOptimize = async () => {
    if (!modelsTrained) {
      showNotification('error', 'Please train models first!');
      return;
    }
    
    const hours = parseFloat(patchHours);
    if (isNaN(hours) || hours <= 0) {
      showNotification('error', 'Please enter valid patch hours (> 0).');
      return;
    }
    
    setLoading(true);
    setLoadingMessage('Running optimization algorithm...');
    
    try {
      const response = await optimize(hours, selectedModel);
      setOptimizationResults(response.results);
      setOptimizationRun(true);
      setCurrentStep(3);
      setLocalShapExplanation(null);
      
      showNotification('success', 
        `Optimized! Selected ${response.results.selected_count} vulnerabilities, ` +
        `reducing risk by ${response.results.percentage_reduced.toFixed(1)}%`
      );
    } catch (error) {
      showNotification('error', 'Optimization failed.');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // Get local SHAP explanation
  const handleExplainVulnerability = async (index: number) => {
    setLoading(true);
    setLoadingMessage('Generating SHAP explanation...');
    setSelectedVulnIndex(index);
    
    try {
      const response = await getLocalExplanation(index);
      setLocalShapExplanation(response.explanation);
      showNotification('success', 'Explanation generated successfully!');
    } catch (error) {
      showNotification('error', 'Failed to generate explanation.');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // Get global SHAP explanation
  const handleGlobalExplanation = async () => {
    setLoading(true);
    setLoadingMessage('Analyzing global feature importance...');
    
    try {
      const response = await getGlobalExplanation();
      setGlobalShapExplanation(response.explanation);
      setShowGlobalShap(true);
      showNotification('success', 'Global analysis complete!');
    } catch (error) {
      showNotification('error', 'Failed to generate global explanation.');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // What-if analysis
  const handleWhatIf = async (
    index: number,
    modifications: Partial<{
      cvss_score: number;
      exploit_available: number;
      asset_criticality: number;
      days_since_disclosure: number;
    }>
  ) => {
    setLoading(true);
    setLoadingMessage('Simulating scenario...');
    
    try {
      const response = await whatIfAnalysis(index, modifications);
      setWhatIfResult(response);
      showNotification('info', 
        `Risk would change by ${response.risk_change > 0 ? '+' : ''}${response.risk_change.toFixed(2)}`
      );
    } catch (error) {
      showNotification('error', 'What-if simulation failed.');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // Export handlers
  const handleExportCSV = async () => {
    try {
      await exportCSV();
      showNotification('success', 'CSV exported successfully!');
    } catch (error) {
      showNotification('error', 'Export failed.');
    }
  };

  const handleExportPDF = async (includeExplanations: boolean) => {
    setLoading(true);
    setLoadingMessage('Generating PDF report...');
    
    try {
      await exportPDF(includeExplanations);
      showNotification('success', 'PDF report generated!');
    } catch (error) {
      showNotification('error', 'PDF generation failed.');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {loading && <LoadingOverlay message={loadingMessage} />}
      {notification && <NotificationToast {...notification} />}
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Tracker */}
        <ProgressTracker currentStep={currentStep} />
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-8">
          {/* Left Sidebar - Controls */}
          <div className="lg:col-span-3">
            <ControlPanel
              dataGenerated={dataGenerated}
              modelsTrained={modelsTrained}
              loading={loading}
              patchHours={patchHours}
              selectedModel={selectedModel}
              onGenerateData={handleGenerateData}
              onTrainModels={handleTrainModels}
              onOptimize={handleOptimize}
              onPatchHoursChange={setPatchHours}
              onModelChange={setSelectedModel}
            />
          </div>
          
          {/* Main Content Area */}
          <div className="lg:col-span-9 space-y-6">
            {/* Model Comparison */}
            {modelComparison && (
              <ModelComparisonCard comparison={modelComparison} />
            )}
            
            {/* Metrics Grid */}
            {optimizationResults && (
              <MetricsGrid results={optimizationResults} />
            )}
            
            {/* Business Impact */}
            {optimizationResults?.business_impact && (
              <BusinessImpactCard impact={optimizationResults.business_impact} />
            )}
            
            {/* Risk Heatmap */}
            {optimizationResults?.risk_heatmap && (
              <RiskHeatmap data={optimizationResults.risk_heatmap} />
            )}
            
            {/* Vulnerability Table */}
            {optimizationResults && (
              <VulnerabilityTable
                vulnerabilities={optimizationResults.selected_vulnerabilities}
                onExplain={handleExplainVulnerability}
                onWhatIf={(index) => {
                  setSelectedVulnIndex(index);
                  setShowWhatIf(true);
                }}
              />
            )}
            
            {/* SHAP Explanations */}
            {optimizationRun && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <button
                  onClick={handleGlobalExplanation}
                  className="btn-secondary"
                >
                  View Global Feature Importance
                </button>
              </div>
            )}
            
            {localShapExplanation && (
              <SHAPExplanationCard 
                explanation={localShapExplanation}
                vulnerabilityIndex={selectedVulnIndex}
              />
            )}
            
            {showGlobalShap && globalShapExplanation && (
              <GlobalSHAPCard 
                explanation={globalShapExplanation}
                onClose={() => setShowGlobalShap(false)}
              />
            )}
            
            {/* What-If Simulator */}
            {showWhatIf && selectedVulnIndex !== null && optimizationResults && (
              <WhatIfSimulator
                vulnerabilityIndex={selectedVulnIndex}
                vulnerability={optimizationResults.selected_vulnerabilities[selectedVulnIndex]}
                onSimulate={handleWhatIf}
                onClose={() => setShowWhatIf(false)}
                result={whatIfResult}
              />
            )}
            
            {/* Export Panel */}
            {optimizationResults && (
              <ExportPanel
                onExportCSV={handleExportCSV}
                onExportPDF={handleExportPDF}
              />
            )}
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}

export default App;
