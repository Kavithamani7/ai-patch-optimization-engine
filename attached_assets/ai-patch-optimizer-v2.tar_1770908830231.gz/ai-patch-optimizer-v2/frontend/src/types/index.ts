// Type definitions for the application

export interface ModelMetrics {
  rmse: number;
  r2: number;
  mae: number;
  train_samples: number;
  test_samples: number;
}

export interface FeatureImportance {
  [feature: string]: number;
}

export interface ModelInfo {
  rmse: number;
  r2: number;
  mae: number;
  train_samples: number;
  test_samples: number;
  feature_importance: FeatureImportance;
}

export interface ModelComparison {
  random_forest: ModelInfo;
  gradient_boosting: ModelInfo;
  winner: 'random_forest' | 'gradient_boosting';
}

export interface Vulnerability {
  vulnerability_id: string;
  cvss_score: number;
  exploit_available: number;
  asset_criticality: number;
  days_since_disclosure: number;
  patch_effort_hours: number;
  predicted_risk: number;
  confidence: number;
  risk_score?: number;
  weighted_risk?: number;
}

export interface SeverityBreakdown {
  [severity: string]: {
    count: number;
    total_risk: number;
    total_hours: number;
  };
}

export interface BusinessImpact {
  summary: string;
  capacity_utilization: number;
  roi_estimate: number;
  remaining_vulnerabilities: number;
}

export interface RiskHeatmapData {
  data: Array<{
    cvss_bin: string;
    asset_criticality: number;
    predicted_risk: number;
    vulnerability_id: number;
  }>;
  x_labels: string[];
  y_labels: string[];
}

export interface OptimizationResult {
  total_vulnerabilities: number;
  selected_count: number;
  total_risk: number;
  risk_reduced: number;
  percentage_reduced: number;
  hours_used: number;
  hours_available: number;
  hours_remaining: number;
  average_confidence: number;
  severity_breakdown: SeverityBreakdown;
  selected_vulnerabilities: Vulnerability[];
  business_impact?: BusinessImpact;
  risk_heatmap?: RiskHeatmapData;
}

export interface SHAPBarData {
  features: string[];
  shap_values: number[];
  feature_values: number[];
}

export interface SHAPWaterfallFeature {
  name: string;
  shap_value: number;
  feature_value: number;
}

export interface SHAPWaterfallData {
  base_value: number;
  features: SHAPWaterfallFeature[];
  final_prediction: number;
}

export interface FeatureContribution {
  shap_value: number;
  feature_value: number;
  impact: string;
}

export interface SHAPExplanation {
  vulnerability_index: number;
  bar_chart: SHAPBarData;
  waterfall: SHAPWaterfallData;
  feature_contributions: {
    [feature: string]: FeatureContribution;
  };
}

export interface GlobalSHAPPoint {
  shap_value: number;
  feature_value: number;
}

export interface GlobalSHAPFeature {
  feature: string;
  mean_abs_shap: number;
  points: GlobalSHAPPoint[];
}

export interface FeatureImportanceRank {
  feature: string;
  importance: number;
  rank: number;
}

export interface FeatureInteraction {
  feature1: string;
  feature2: string;
  correlation: number;
  strength: string;
}

export interface GlobalSHAPExplanation {
  summary_plot: GlobalSHAPFeature[];
  feature_importance: FeatureImportanceRank[];
  feature_interactions: FeatureInteraction[];
  total_samples: number;
}

export interface WhatIfOriginal {
  features: {
    [key: string]: number;
  };
  predicted_risk: number;
}

export interface WhatIfModified {
  features: {
    [key: string]: number;
  };
  predicted_risk: number;
}

export interface WhatIfResult {
  status: string;
  original: WhatIfOriginal;
  modified: WhatIfModified;
  risk_change: number;
  risk_change_percentage: number;
}
