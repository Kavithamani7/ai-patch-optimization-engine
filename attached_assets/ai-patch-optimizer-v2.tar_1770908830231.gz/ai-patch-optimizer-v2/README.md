# AI Patch Optimizer v2.0 - Production Grade

A sophisticated AI-powered vulnerability patch optimization dashboard that uses machine learning and optimization algorithms to prioritize security patches based on risk, resource constraints, and business impact.

## Features

### Core Capabilities
- **Synthetic Data Generation**: Create realistic vulnerability datasets for testing
- **ML Model Comparison**: Train and compare Random Forest vs Gradient Boosting models
- **Optimization Engine**: Knapsack algorithm for optimal patch selection under resource constraints
- **SHAP Explainability**: Local and global explanations for ML predictions
- **What-If Analysis**: Simulate scenarios to understand feature impact on risk
- **Risk Visualization**: Interactive heatmaps showing risk by severity and criticality

### Production Features
- ✅ Workflow-based UX with progress tracking
- ✅ Sortable, filterable vulnerability tables with severity color coding
- ✅ Model comparison with feature importance visualization
- ✅ Prediction confidence scores
- ✅ Business impact summary and ROI estimation
- ✅ Patch capacity utilization tracking
- ✅ CSV and PDF export functionality
- ✅ Loading states and proper error handling
- ✅ Clean, modular component architecture
- ✅ Professional UI with consistent spacing and shadows

## Technology Stack

### Backend
- **Framework**: FastAPI (Python)
- **ML Libraries**: scikit-learn (RandomForest, GradientBoosting)
- **Explainability**: SHAP
- **Optimization**: Dynamic Programming
- **Export**: ReportLab (PDF), Pandas (CSV)

### Frontend
- **Framework**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Build Tool**: Vite
- **State Management**: React Hooks

## Quick Start

### Prerequisites
- Python 3.9+
- Node.js 18+
- npm or yarn

### Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run server
uvicorn app.main:app --reload
```

Backend will run on `http://localhost:8000`

### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Run development server
npm run dev
```

Frontend will run on `http://localhost:5173`

## Usage Guide

### Step 1: Generate Data
Click "1. Generate Data" to create 1000 synthetic vulnerability records with varying CVSS scores, exploit availability, asset criticality, and patch effort.

### Step 2: Train Models
Click "2. Train Models" to train both Random Forest and Gradient Boosting models. The system will compare them and show which performs better.

### Step 3: Configure & Optimize
- Enter available patch hours (e.g., 40)
- Select your preferred model (RF or GBM)
- Click "3. Optimize Patches"

The system will select the optimal subset of vulnerabilities to patch that maximizes risk reduction within your time constraints.

### Step 4: Analyze Results
- **Metrics Grid**: View total vulnerabilities, risk reduced, hours used, and confidence
- **Business Impact**: See ROI, capacity utilization, and strategic summary
- **Risk Heatmap**: Visualize risk distribution by severity and criticality
- **Vulnerability Table**: Sort/filter selected patches, click "Explain" for SHAP analysis
- **What-If Simulator**: Modify features to see how risk predictions change
- **Global SHAP**: View overall feature importance across all vulnerabilities

### Step 5: Export
- Export to CSV for data analysis
- Generate PDF report with executive summary and detailed findings

## Architecture

### Backend Structure
```
backend/
├── app/
│   ├── __init__.py
│   ├── main.py           # FastAPI endpoints
│   ├── data.py           # Data generation
│   ├── model.py          # ML models (RF, GBM)
│   ├── optimizer.py      # Knapsack optimization
│   ├── explain.py        # SHAP explainability
│   └── export.py         # CSV/PDF generation
└── requirements.txt
```

### Frontend Structure
```
frontend/
├── src/
│   ├── components/       # React components
│   │   ├── Header.tsx
│   │   ├── ProgressTracker.tsx
│   │   ├── ControlPanel.tsx
│   │   ├── MetricsGrid.tsx
│   │   ├── ModelComparisonCard.tsx
│   │   ├── VulnerabilityTable.tsx
│   │   ├── RiskHeatmap.tsx
│   │   ├── SHAPExplanationCard.tsx
│   │   ├── GlobalSHAPCard.tsx
│   │   ├── WhatIfSimulator.tsx
│   │   ├── BusinessImpactCard.tsx
│   │   ├── ExportPanel.tsx
│   │   ├── Footer.tsx
│   │   ├── NotificationToast.tsx
│   │   └── LoadingOverlay.tsx
│   ├── services/
│   │   └── api.ts        # API client
│   ├── types/
│   │   └── index.ts      # TypeScript definitions
│   ├── App.tsx           # Main application
│   ├── main.tsx          # Entry point
│   └── index.css         # Global styles
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── vite.config.ts
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Health check |
| `/generate-data` | POST | Generate vulnerability dataset |
| `/train-models` | POST | Train RF and GBM models |
| `/optimize` | POST | Run optimization with constraints |
| `/explain/local` | POST | Get SHAP explanation for vulnerability |
| `/explain/global` | POST | Get global feature importance |
| `/what-if` | POST | Simulate feature modifications |
| `/export/csv` | GET | Export results to CSV |
| `/export/pdf` | POST | Generate PDF report |

## Key Algorithms

### Knapsack Optimization
Uses dynamic programming to solve the 0/1 knapsack problem:
- **Items**: Vulnerabilities
- **Weights**: Patch effort hours
- **Values**: Predicted risk × confidence
- **Constraint**: Available patch hours

### SHAP Explainability
- **Local**: Explains individual predictions using TreeExplainer
- **Global**: Aggregates SHAP values across dataset for feature importance
- **Visualizations**: Bar charts and waterfall plots

## Development Tips

### Adding New Features
1. Backend: Add endpoint in `main.py`, implement logic in respective module
2. Frontend: Create component in `components/`, add type in `types/index.ts`
3. Update API service in `services/api.ts`

### Styling Guidelines
- Use Tailwind utility classes
- Follow existing color scheme (blue primary, semantic colors)
- Maintain consistent spacing (p-4, p-6, gap-4, gap-6)
- Use shadow-sm for cards, shadow-md for hover states

### Best Practices
- Keep components under 300 lines
- Use TypeScript for type safety
- Handle loading and error states
- Provide user feedback via notifications
- Make UI responsive (mobile-friendly)

## Troubleshooting

### Backend Not Starting
```bash
# Check if port 8000 is in use
lsof -i :8000

# Verify Python version
python --version  # Should be 3.9+

# Check dependencies
pip list
```

### Frontend Not Building
```bash
# Clear cache
rm -rf node_modules package-lock.json
npm install

# Check Node version
node --version  # Should be 18+
```

### CORS Errors
Ensure backend CORS middleware allows frontend origin in `main.py`:
```python
allow_origins=["http://localhost:5173"]
```

## Performance Optimization

- **Backend**: Model training caches results in memory (use Redis in production)
- **Frontend**: React.memo for expensive components, useMemo for filtered data
- **Data**: Sample large datasets for SHAP summary plots (max 100 points per feature)

## Security Considerations

For production deployment:
- [ ] Add authentication (JWT tokens)
- [ ] Validate all user inputs
- [ ] Rate limit API endpoints
- [ ] Use HTTPS
- [ ] Sanitize file uploads
- [ ] Implement RBAC for multi-tenant use

## Future Enhancements

- [ ] Real-time vulnerability feed integration (NVD API)
- [ ] Multi-user collaboration features
- [ ] Historical tracking and trend analysis
- [ ] Integration with patch management tools
- [ ] Advanced ML models (XGBoost, Neural Networks)
- [ ] Automated report scheduling
- [ ] Dashboard customization and saved views

## License

MIT License - See LICENSE file for details

## Authors

Built with precision and professionalism for production-grade vulnerability management.

## Support

For issues or questions:
- Check documentation above
- Review example code in components
- Inspect browser console and backend logs
