# Deployment Guide - AI Patch Optimizer v2.0

## Quick Deployment Checklist

```bash
# 1. Extract the archive
tar -xzf ai-patch-optimizer-v2.tar.gz
cd ai-patch-optimizer-v2

# 2. Backend setup
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload

# 3. Frontend setup (new terminal)
cd frontend
npm install
npm run dev

# 4. Access application
# Frontend: http://localhost:5173
# Backend API Docs: http://localhost:8000/docs
```

## Complete File Structure

```
ai-patch-optimizer-v2/
├── README.md                    # Comprehensive documentation
├── QUICKSTART.md               # 5-minute setup guide
├── PROJECT_OVERVIEW.md         # Feature comparison & architecture
├── .gitignore                  # Git ignore patterns
│
├── backend/                    # Python FastAPI backend
│   ├── app/
│   │   ├── __init__.py        # Package initialization
│   │   ├── main.py            # FastAPI app + endpoints
│   │   ├── data.py            # Synthetic data generation
│   │   ├── model.py           # ML models (RF + GBM)
│   │   ├── optimizer.py       # Knapsack optimization
│   │   ├── explain.py         # SHAP explainability
│   │   └── export.py          # CSV/PDF generation
│   └── requirements.txt        # Python dependencies
│
└── frontend/                   # React + TypeScript frontend
    ├── public/
    ├── src/
    │   ├── components/        # 14 React components
    │   │   ├── Header.tsx
    │   │   ├── Footer.tsx
    │   │   ├── ProgressTracker.tsx
    │   │   ├── ControlPanel.tsx
    │   │   ├── MetricsGrid.tsx
    │   │   ├── ModelComparisonCard.tsx
    │   │   ├── VulnerabilityTable.tsx
    │   │   ├── RiskHeatmap.tsx
    │   │   ├── SHAPExplanationCard.tsx
    │   │   ├── GlobalSHAPCard.tsx
    │   │   ├── WhatIfSimulator.tsx
    │   │   ├── BusinessImpactCard.tsx
    │   │   ├── ExportPanel.tsx
    │   │   ├── NotificationToast.tsx
    │   │   └── LoadingOverlay.tsx
    │   ├── services/
    │   │   └── api.ts         # API client
    │   ├── types/
    │   │   └── index.ts       # TypeScript definitions
    │   ├── App.tsx            # Main application
    │   ├── main.tsx           # Entry point
    │   └── index.css          # Global styles
    ├── index.html             # HTML template
    ├── package.json           # Node dependencies
    ├── tailwind.config.js     # Tailwind CSS config
    ├── tsconfig.json          # TypeScript config
    └── vite.config.ts         # Vite build config
```

## Technology Requirements

### Backend
- **Python**: 3.9 or higher
- **Dependencies**:
  - FastAPI 0.109.0 (web framework)
  - uvicorn 0.27.0 (ASGI server)
  - scikit-learn 1.4.0 (ML models)
  - SHAP 0.44.0 (explainability)
  - pandas 2.1.4 (data processing)
  - numpy 1.26.3 (numerical computing)
  - reportlab 4.0.8 (PDF generation)
  - pydantic 2.5.3 (data validation)

### Frontend
- **Node.js**: 18 or higher
- **npm**: 9 or higher
- **Dependencies**:
  - React 18.2.0
  - TypeScript 5.2.2
  - Vite 5.0.8
  - Tailwind CSS 3.4.0

## Development Setup

### 1. Backend Development

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate it
source venv/bin/activate  # macOS/Linux
# OR
venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Run with auto-reload (development)
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Run without reload (testing)
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

**Backend will be available at:**
- API: http://localhost:8000
- Interactive docs: http://localhost:8000/docs
- Alternative docs: http://localhost:8000/redoc

### 2. Frontend Development

```bash
cd frontend

# Install dependencies
npm install

# Run development server (with hot reload)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

**Frontend will be available at:**
- Development: http://localhost:5173
- Preview: http://localhost:4173

## Production Deployment

### Option 1: Docker (Recommended)

Create `Dockerfile` in backend:
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app/ ./app/

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Create `Dockerfile` in frontend:
```dockerfile
FROM node:18-alpine as build

WORKDIR /app
COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Create `docker-compose.yml`:
```yaml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - PYTHONUNBUFFERED=1
    
  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - backend
```

Deploy:
```bash
docker-compose up -d
```

### Option 2: Traditional Server

**Backend with Gunicorn:**
```bash
cd backend
pip install gunicorn

# Production server with 4 workers
gunicorn app.main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000 \
  --access-logfile - \
  --error-logfile -
```

**Frontend with nginx:**
```bash
cd frontend
npm run build

# Copy dist/ to nginx web root
sudo cp -r dist/* /var/www/html/
```

**nginx configuration:**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    # Frontend
    location / {
        root /var/www/html;
        try_files $uri $uri/ /index.html;
    }
    
    # Backend API proxy
    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Option 3: Cloud Platforms

**AWS:**
- Frontend: S3 + CloudFront
- Backend: Elastic Beanstalk or ECS
- Database: RDS (if adding persistence)

**Google Cloud:**
- Frontend: Cloud Storage + Cloud CDN
- Backend: Cloud Run or App Engine
- Database: Cloud SQL

**Heroku:**
```bash
# Backend
cd backend
echo "web: uvicorn app.main:app --host 0.0.0.0 --port $PORT" > Procfile
git init && git add . && git commit -m "Initial"
heroku create your-app-backend
git push heroku main

# Frontend
cd frontend
npm run build
# Use Heroku buildpack or serve via backend
```

## Environment Variables

### Backend (.env)
```bash
# API Configuration
API_HOST=0.0.0.0
API_PORT=8000

# CORS
CORS_ORIGINS=http://localhost:5173,https://your-domain.com

# Model Configuration
MODEL_CACHE_TTL=3600
MAX_SAMPLES=1000

# Export Configuration
PDF_FONT=Helvetica
MAX_PDF_VULNERABILITIES=100
```

### Frontend (.env)
```bash
VITE_API_URL=http://localhost:8000
VITE_APP_VERSION=2.0.0
```

## Performance Tuning

### Backend Optimization
```python
# In main.py, add caching
from functools import lru_cache

@lru_cache(maxsize=128)
def get_model():
    # Cache trained models
    pass
```

### Frontend Optimization
```typescript
// Use React.memo for expensive components
export default React.memo(VulnerabilityTable);

// Use useMemo for filtered data
const filteredData = useMemo(() => {
    return vulnerabilities.filter(...)
}, [vulnerabilities, filters]);
```

## Monitoring & Logging

### Backend Logging
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

### Error Tracking
- **Sentry**: Add Sentry SDK for error tracking
- **DataDog**: Application performance monitoring
- **CloudWatch**: If using AWS

## Security Checklist

Before going to production:

- [ ] Add authentication (JWT tokens)
- [ ] Implement rate limiting
- [ ] Enable HTTPS/SSL
- [ ] Sanitize user inputs
- [ ] Add CSRF protection
- [ ] Configure CORS properly
- [ ] Use environment variables for secrets
- [ ] Enable security headers
- [ ] Add input validation
- [ ] Implement API key authentication

## Backup & Recovery

### Data Backup
```bash
# If using database, schedule backups
# For now, models are in-memory, so backup:
# - Trained model files (pickle)
# - Configuration files
# - User preferences
```

### Disaster Recovery
- Use version control (Git)
- Deploy to multiple regions
- Keep database backups
- Document rollback procedures

## Troubleshooting Production Issues

### High Memory Usage
```bash
# Monitor backend memory
ps aux | grep uvicorn

# Limit worker processes
gunicorn --workers 2  # Instead of 4
```

### Slow Response Times
- Enable caching for ML predictions
- Use Redis for session storage
- Optimize SHAP calculations (sample data)
- Add database indexing

### Connection Issues
```bash
# Check if services are running
systemctl status backend
systemctl status nginx

# Check ports
netstat -tulpn | grep :8000
netstat -tulpn | grep :80
```

## Scaling Strategies

### Horizontal Scaling
- Load balancer (nginx, HAProxy)
- Multiple backend instances
- Shared cache (Redis)
- Database replication

### Vertical Scaling
- Increase server resources
- Optimize algorithms
- Use faster hardware

## Maintenance Tasks

### Regular Updates
```bash
# Update Python dependencies
pip list --outdated
pip install --upgrade <package>

# Update Node dependencies
npm outdated
npm update
```

### Database Maintenance (if added)
- Vacuum and analyze
- Index optimization
- Query performance monitoring

### Log Rotation
```bash
# Configure logrotate
/var/log/optimizer/*.log {
    daily
    rotate 7
    compress
    delaycompress
    notifempty
}
```

## Support & Documentation

- **Code Documentation**: Inline comments in all files
- **API Documentation**: http://localhost:8000/docs
- **User Guide**: See README.md
- **Quick Start**: See QUICKSTART.md
- **Architecture**: See PROJECT_OVERVIEW.md

## Contact & Credits

Built with professional standards for production deployment.

For questions or support:
- Review documentation files
- Check inline code comments
- Inspect browser/server logs
- Verify environment setup

---

**Version**: 2.0.0  
**Last Updated**: February 2026  
**Status**: Production Ready
